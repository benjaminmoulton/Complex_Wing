# PFlow_Complex_Sphere
The Complex_Sphere.py file is my code, the run_CS.py file is what you can run to test my code, and run_CS_input.json is the input file you can modify to test my code.

The files need to be in the same directory.